/* ============================================================
   L'Organi Flow — Servidor (Fase A)
   Autenticação com sessões, papéis de acesso (RBAC), auditoria
   e API real de Contatos/Kanban. Serve o protótipo após login.
   ============================================================ */
const path = require('path');
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

const PORTA = process.env.PORTA || 3000;

const db = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_SENHA || '',
  database: 'lorgani_flow',
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4'
});

const app = express();
app.use(express.json());
app.use(session({
  secret: process.env.SESSAO_SEGREDO || 'troque-este-segredo-lorgani',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 10 } // 10 horas (turno da clínica)
}));

/* ---------- auditoria ---------- */
async function auditar(req, acao, alvo, detalhe) {
  try {
    await db.query(
      'INSERT INTO auditoria (usuario_id, acao, alvo, detalhe, ip) VALUES (?,?,?,?,?)',
      [req.session.usuario ? req.session.usuario.id : null, acao, alvo || null,
       detalhe ? JSON.stringify(detalhe).slice(0, 900) : null, req.ip]
    );
  } catch (e) { console.error('auditoria falhou:', e.message); }
}

/* ---------- middlewares de acesso ---------- */
function exigeLogin(req, res, next) {
  if (req.session.usuario) return next();
  if (req.path.startsWith('/api/')) return res.status(401).json({ erro: 'não autenticado' });
  return res.redirect('/login.html');
}
function exigePapel(...papeis) {
  return (req, res, next) => {
    if (!req.session.usuario) return res.status(401).json({ erro: 'não autenticado' });
    if (papeis.includes(req.session.usuario.papel) || req.session.usuario.papel === 'admin') return next();
    return res.status(403).json({ erro: 'sem permissão para este módulo' });
  };
}

/* ---------- autenticação ---------- */
app.post('/api/login', async (req, res) => {
  const { email, senha } = req.body || {};
  if (!email || !senha) return res.status(400).json({ erro: 'informe e-mail e senha' });
  const [rows] = await db.query('SELECT * FROM usuarios WHERE email = ? AND ativo = 1', [email.trim().toLowerCase()]);
  const u = rows[0];
  if (!u || !(await bcrypt.compare(senha, u.senha_hash))) {
    await auditar(req, 'login_falhou', email);
    return res.status(401).json({ erro: 'e-mail ou senha incorretos' });
  }
  req.session.usuario = { id: u.id, nome: u.nome, papel: u.papel };
  await auditar(req, 'login', email);
  res.json({ ok: true, usuario: req.session.usuario });
});

app.post('/api/logout', (req, res) => { req.session.destroy(() => res.json({ ok: true })); });

app.get('/api/me', (req, res) => {
  if (!req.session.usuario) return res.status(401).json({ erro: 'não autenticado' });
  res.json(req.session.usuario);
});

/* ---------- usuários (somente admin) ---------- */
app.get('/api/usuarios', exigePapel('admin'), async (req, res) => {
  const [rows] = await db.query('SELECT id, nome, email, papel, ativo, criado_em FROM usuarios ORDER BY nome');
  res.json(rows);
});
app.post('/api/usuarios', exigePapel('admin'), async (req, res) => {
  const { nome, email, senha, papel } = req.body || {};
  if (!nome || !email || !senha) return res.status(400).json({ erro: 'nome, e-mail e senha são obrigatórios' });
  const hash = await bcrypt.hash(senha, 10);
  await db.query('INSERT INTO usuarios (nome, email, senha_hash, papel) VALUES (?,?,?,?)',
    [nome, email.trim().toLowerCase(), hash, papel || 'recepcao']);
  await auditar(req, 'usuario_criado', email);
  res.json({ ok: true });
});

/* ---------- contatos / CRM (recepção, médicos e admin) ---------- */
app.get('/api/contatos', exigeLogin, async (req, res) => {
  const [rows] = await db.query('SELECT * FROM contatos ORDER BY atualizado_em DESC');
  res.json(rows);
});
app.post('/api/contatos', exigePapel('recepcao', 'medico'), async (req, res) => {
  const { nome, whatsapp, convenio } = req.body || {};
  if (!nome) return res.status(400).json({ erro: 'nome é obrigatório' });
  const [r] = await db.query('INSERT INTO contatos (nome, whatsapp, convenio) VALUES (?,?,?)',
    [nome, whatsapp || null, convenio || 'Particular']);
  await db.query('INSERT INTO eventos_contato (contato_id, titulo, detalhe) VALUES (?,?,?)',
    [r.insertId, 'Contato criado', 'por ' + req.session.usuario.nome]);
  await auditar(req, 'contato_criado', nome);
  res.json({ ok: true, id: r.insertId });
});
app.patch('/api/contatos/:id/etapa', exigePapel('recepcao', 'medico'), async (req, res) => {
  const { etapa } = req.body || {};
  const validas = ['novo','conversa','qualificado','agendado','atendido','recorrente'];
  if (!validas.includes(etapa)) return res.status(400).json({ erro: 'etapa inválida' });
  await db.query('UPDATE contatos SET etapa = ? WHERE id = ?', [etapa, req.params.id]);
  await db.query('INSERT INTO eventos_contato (contato_id, titulo, detalhe) VALUES (?,?,?)',
    [req.params.id, 'Movido para ' + etapa, 'por ' + req.session.usuario.nome]);
  await auditar(req, 'kanban_movido', 'contato #' + req.params.id, { etapa });
  res.json({ ok: true });
});
app.get('/api/contatos/:id/eventos', exigeLogin, async (req, res) => {
  const [rows] = await db.query('SELECT * FROM eventos_contato WHERE contato_id = ? ORDER BY criado_em DESC', [req.params.id]);
  res.json(rows);
});

/* ---------- exemplo de rota restrita (Fase C usa de verdade) ---------- */
app.get('/api/financeiro/resumo', exigePapel('financeiro'), async (req, res) => {
  const [[r]] = await db.query(
    "SELECT COALESCE(SUM(CASE WHEN status='pago' THEN valor END),0) recebido, " +
    "COALESCE(SUM(CASE WHEN status IN ('pendente','atrasado') THEN valor END),0) a_receber FROM lancamentos");
  res.json(r);
});

/* ---------- arquivos ---------- */
app.get('/', (req, res) => res.redirect(req.session.usuario ? '/app' : '/login.html'));
app.get('/app', exigeLogin, (req, res) => res.sendFile(path.join(__dirname, '..', 'index.html')));
app.use(express.static(path.join(__dirname, 'publico')));           // login.html
app.use('/assets', express.static(path.join(__dirname, '..', '..', 'assets'))); // logo e imagens

app.listen(PORTA, () => {
  console.log('');
  console.log('  L\'Organi Flow rodando!');
  console.log('  Neste computador:  http://localhost:' + PORTA);
  console.log('  Na rede da clínica: http://SEU-IP-LOCAL:' + PORTA + '  (veja o IP com: ipconfig)');
  console.log('');
});
