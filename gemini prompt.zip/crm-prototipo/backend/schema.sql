-- ============================================================
-- L'Organi Flow — Banco de dados (MariaDB)  ·  Fase A
-- Criar com:  mysql -u root -p < schema.sql
-- ============================================================
CREATE DATABASE IF NOT EXISTS lorgani_flow
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lorgani_flow;

-- ---------- usuários e acesso ----------
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  senha_hash VARCHAR(100) NOT NULL,
  papel ENUM('admin','medico','recepcao','financeiro') NOT NULL DEFAULT 'recepcao',
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- CRM ----------
CREATE TABLE contatos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(140) NOT NULL,
  whatsapp VARCHAR(20),
  email VARCHAR(160),
  cpf VARCHAR(14),
  nascimento DATE NULL,
  convenio VARCHAR(80) DEFAULT 'Particular',
  amplimed_id VARCHAR(30) NULL,
  etapa ENUM('novo','conversa','qualificado','agendado','atendido','recorrente') NOT NULL DEFAULT 'novo',
  origem VARCHAR(40) DEFAULT 'whatsapp',
  observacoes TEXT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE eventos_contato (          -- linha do tempo do paciente
  id INT AUTO_INCREMENT PRIMARY KEY,
  contato_id INT NOT NULL,
  titulo VARCHAR(160) NOT NULL,
  detalhe VARCHAR(255),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (contato_id) REFERENCES contatos(id) ON DELETE CASCADE
);

-- ---------- agendamento (Fase C usa; já nasce pronta) ----------
CREATE TABLE agendamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contato_id INT NOT NULL,
  profissional VARCHAR(120) NOT NULL,
  especialidade VARCHAR(80) NOT NULL,
  inicio DATETIME NOT NULL,
  status ENUM('agendado','confirmado','atendido','faltou','cancelado') DEFAULT 'agendado',
  criado_por INT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (contato_id) REFERENCES contatos(id) ON DELETE CASCADE
);

-- ---------- financeiro (Fase C) ----------
CREATE TABLE lancamentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contato_id INT NULL,
  descricao VARCHAR(200) NOT NULL,
  tipo ENUM('receita','despesa') NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  forma VARCHAR(40) DEFAULT 'pix',
  status ENUM('pendente','pago','atrasado','a_faturar') DEFAULT 'pendente',
  vencimento DATE NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (contato_id) REFERENCES contatos(id) ON DELETE SET NULL
);

-- ---------- estoque (Fase C) ----------
CREATE TABLE insumos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(140) NOT NULL,
  lote VARCHAR(40),
  validade DATE NULL,
  quantidade INT NOT NULL DEFAULT 0,
  minimo INT NOT NULL DEFAULT 0,
  custo_unit DECIMAL(10,2) NULL
);

CREATE TABLE movimentos_estoque (
  id INT AUTO_INCREMENT PRIMARY KEY,
  insumo_id INT NOT NULL,
  delta INT NOT NULL,                    -- +entrada / -saída
  motivo VARCHAR(160),
  usuario_id INT NULL,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (insumo_id) REFERENCES insumos(id) ON DELETE CASCADE
);

-- ---------- auditoria (LGPD / segurança) ----------
CREATE TABLE auditoria (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NULL,
  acao VARCHAR(60) NOT NULL,
  alvo VARCHAR(120),
  detalhe TEXT,
  ip VARCHAR(45),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_contatos_etapa ON contatos(etapa);
CREATE INDEX idx_agend_inicio ON agendamentos(inicio);
CREATE INDEX idx_lanc_status ON lancamentos(status);
