/* Cria os 10 usuários iniciais e os pacientes de exemplo.
   Rodar UMA vez, depois do schema.sql:  node seed.js               */
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

const USUARIOS = [
  // [nome, email, papel]  — senha inicial de todos: Lorgani@2026 (trocar no 1º uso)
  ['Administrador',            'admin@lorgani.com.br',      'admin'],
  ['Dra. Rita Soler',          'rita@lorgani.com.br',       'medico'],
  ['Dra. Luciane Freitas',     'luciane@lorgani.com.br',    'medico'],
  ['Dra. Luciana Segatto',     'segatto@lorgani.com.br',    'medico'],
  ['Renata Toledo',            'renata@lorgani.com.br',     'medico'],
  ['Silvia Manzi',             'silvia@lorgani.com.br',     'medico'],
  ['Recepção 1',               'recepcao1@lorgani.com.br',  'recepcao'],
  ['Recepção 2',               'recepcao2@lorgani.com.br',  'recepcao'],
  ['Recepção 3',               'recepcao3@lorgani.com.br',  'recepcao'],
  ['Financeiro',               'financeiro@lorgani.com.br', 'financeiro'],
];

const CONTATOS = [
  ['Marina Alves',  '+5511994212381', 'qualificado', 'Particular'],
  ['Carla Freitas', '+5511996552074', 'conversa',    'Particular'],
  ['João Santos',   '+5511980774463', 'agendado',    'Particular'],
  ['Rafael Pinto',  '+5511988124407', 'novo',        'Particular'],
  ['Lucas Barros',  '+5511982216650', 'recorrente',  'Particular'],
  ['Ana Lima',      '+5511993407726', 'atendido',    'Particular'],
];

(async () => {
  const db = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_SENHA || '',
    database: 'lorgani_flow'
  });

  const hash = await bcrypt.hash('Lorgani@2026', 10);
  for (const [nome, email, papel] of USUARIOS) {
    await db.query(
      'INSERT INTO usuarios (nome, email, senha_hash, papel) VALUES (?,?,?,?) ' +
      'ON DUPLICATE KEY UPDATE nome = VALUES(nome), papel = VALUES(papel)',
      [nome, email, hash, papel]);
  }
  console.log('✓ ' + USUARIOS.length + ' usuários criados (senha inicial: Lorgani@2026)');

  const [[{ n }]] = await db.query('SELECT COUNT(*) n FROM contatos');
  if (n === 0) {
    for (const [nome, wpp, etapa, conv] of CONTATOS) {
      const [r] = await db.query(
        'INSERT INTO contatos (nome, whatsapp, etapa, convenio) VALUES (?,?,?,?)',
        [nome, wpp, etapa, conv]);
      await db.query(
        'INSERT INTO eventos_contato (contato_id, titulo, detalhe) VALUES (?,?,?)',
        [r.insertId, 'Contato importado', 'carga inicial do sistema']);
    }
    console.log('✓ ' + CONTATOS.length + ' contatos de exemplo criados');
  } else {
    console.log('• contatos já existiam — mantidos');
  }

  await db.end();
  console.log('Pronto! Agora rode:  node server.js');
})().catch(e => { console.error('ERRO:', e.message); process.exit(1); });
